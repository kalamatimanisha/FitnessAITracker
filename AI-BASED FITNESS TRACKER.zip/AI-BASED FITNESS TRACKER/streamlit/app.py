import streamlit as st
import requests

st.title('AI Fitness Tracker')

menu = ['Login', 'Signup', 'BMI Calculator']
choice = st.sidebar.selectbox('Menu', menu)

if choice == 'Login':
    st.subheader('Login to Your Account')
    email = st.text_input('Email')
    password = st.text_input('Password', type='password')
    if st.button('Login'):
        res = requests.post('http://127.0.0.1:5000/login', json={'email': email, 'password': password})
        st.success(res.json()['message'])

elif choice == 'Signup':
    st.subheader('Create New Account')
    username = st.text_input('Username')
    email = st.text_input('Email')
    password = st.text_input('Password', type='password')
    if st.button('Signup'):
        res = requests.post('http://127.0.0.1:5000/signup', json={'username': username, 'email': email, 'password': password})
        st.success(res.json()['message'])

elif choice == 'BMI Calculator':
    st.subheader('Calculate BMI')
    weight = st.number_input('Weight (in kg)')
    height = st.number_input('Height (in cm)')
    if st.button('Calculate'):
        res = requests.post('http://127.0.0.1:5000/bmi', json={'weight': weight, 'height': height})
        data = res.json()
        st.write(f"BMI: {data['bmi']}, Status: {data['status']}")