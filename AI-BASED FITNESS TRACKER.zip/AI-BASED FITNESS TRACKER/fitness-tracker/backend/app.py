from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from models import User, FitnessData
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

@app.route('/signup', methods=['POST'])
def signup():
    data = request.json
    hashed_password = generate_password_hash(data['password'], method='sha256')
    new_user = User(username=data['username'], email=data['email'], password=hashed_password)
    db.session.add(new_user)
    db.session.commit()
    return jsonify({'message': 'User registered successfully!'})

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(email=data['email']).first()
    if not user or not check_password_hash(user.password, data['password']):
        return jsonify({'message': 'Login failed!'})
    return jsonify({'message': 'Login successful!'})

@app.route('/bmi', methods=['POST'])
def calculate_bmi():
    data = request.json
    weight = float(data['weight'])
    height = float(data['height']) / 100  # convert cm to meters
    bmi = round(weight / (height ** 2), 2)
    return jsonify({'bmi': bmi, 'status': get_bmi_status(bmi)})

def get_bmi_status(bmi):
    if bmi < 18.5:
        return "Underweight"
    elif 18.5 <= bmi < 24.9:
        return "Normal weight"
    elif 25 <= bmi < 29.9:
        return "Overweight"
    else:
        return "Obesity"

if __name__ == '__main__':
    app.run(debug=True)