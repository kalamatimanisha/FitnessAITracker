import React, { useState } from 'react';

function GoalSetup() {
  const [goal, setGoal] = useState('');

  const handleGoalSetup = () => {
    alert(`Your goal is set to: ${goal}`);
  };

  return (
    <div>
      <h2>Set Your Fitness Goals</h2>
      <input
        type="text"
        placeholder="Enter your goal"
        onChange={(e) => setGoal(e.target.value)}
      />
      <button onClick={handleGoalSetup}>Set Goal</button>
    </div>
  );
}

export default GoalSetup;