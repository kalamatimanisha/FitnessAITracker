import React from 'react';
import { Link } from 'react-router-dom';

function Dashboard() {
  return (
    <div>
      <h2>Welcome to Your Dashboard</h2>
      <ul>
        <li><Link to="/goal-setup">Set Goals</Link></li>
        <li><Link to="/bmi">Calculate BMI</Link></li>
        <li><Link to="/">Logout</Link></li>
      </ul>
    </div>
  );
}

export default Dashboard;