import React, { useState } from 'react';

function BMI() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [result, setResult] = useState(null);

  const calculateBMI = async () => {
    const response = await fetch('http://127.0.0.1:5000/bmi', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ weight, height }),
    });
    const data = await response.json();
    setResult(`BMI: ${data.bmi}, Status: ${data.status}`);
  };

  return (
    <div>
      <h2>BMI Calculator</h2>
      <input
        type="number"
        placeholder="Weight (kg)"
        onChange={(e) => setWeight(e.target.value)}
      />
      <input
        type="number"
        placeholder="Height (cm)"
        onChange={(e) => setHeight(e.target.value)}
      />
      <button onClick={calculateBMI}>Calculate BMI</button>
      {result && <p>{result}</p>}
    </div>
  );
}

export default BMI;